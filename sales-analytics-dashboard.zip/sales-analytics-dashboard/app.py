"""
app.py
-------
Interactive Streamlit dashboard for the Sales & Business Analytics project.

Features:
  - Drill-down filters: date range, region, product category
  - KPI cards: total revenue, total orders, avg order value, churn rate
  - Monthly revenue trend chart
  - Top product categories chart
  - Regional performance chart
  - Raw / filtered data explorer

Run:
    streamlit run app.py
"""

import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_theme(style="whitegrid")

st.set_page_config(
    page_title="Sales & Business Analytics Dashboard",
    page_icon="📊",
    layout="wide",
)


@st.cache_data
def load_data(path: str = "data/cleaned_sales_data.csv") -> pd.DataFrame:
    df = pd.read_csv(path, parse_dates=["order_date"])
    return df


def kpi_cards(df: pd.DataFrame) -> None:
    total_revenue = df["revenue"].sum()
    total_orders = df["order_id"].nunique()
    avg_order_value = total_revenue / total_orders if total_orders else 0
    unique_customers = df.drop_duplicates("customer_id")
    churn = unique_customers["is_churned"].mean() * 100 if len(unique_customers) else 0

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total Revenue", f"₹{total_revenue:,.0f}")
    c2.metric("Total Orders", f"{total_orders:,}")
    c3.metric("Avg Order Value", f"₹{avg_order_value:,.0f}")
    c4.metric("Customer Churn Rate", f"{churn:.1f}%")


def monthly_trend_chart(df: pd.DataFrame) -> None:
    trend = df.groupby("order_month")["revenue"].sum().reset_index().sort_values("order_month")
    fig, ax = plt.subplots(figsize=(10, 4))
    sns.lineplot(data=trend, x="order_month", y="revenue", marker="o", ax=ax)
    ax.set_title("Monthly Revenue Trend")
    ax.set_xlabel("Month")
    ax.set_ylabel("Revenue (₹)")
    plt.xticks(rotation=45)
    st.pyplot(fig)


def category_chart(df: pd.DataFrame) -> None:
    cat = (
        df.groupby("product_category")["revenue"]
        .sum()
        .sort_values(ascending=False)
        .reset_index()
    )
    fig, ax = plt.subplots(figsize=(8, 4))
    sns.barplot(data=cat, x="revenue", y="product_category", hue="product_category",
                palette="Blues_r", legend=False, ax=ax)
    ax.set_title("Revenue by Product Category")
    ax.set_xlabel("Revenue (₹)")
    ax.set_ylabel("")
    st.pyplot(fig)


def region_chart(df: pd.DataFrame) -> None:
    region = (
        df.groupby("region")
        .agg(total_revenue=("revenue", "sum"), orders=("order_id", "count"))
        .sort_values("total_revenue", ascending=False)
        .reset_index()
    )
    fig, ax = plt.subplots(figsize=(8, 4))
    sns.barplot(data=region, x="region", y="total_revenue", hue="region",
                palette="Greens_r", legend=False, ax=ax)
    ax.set_title("Regional Sales Performance")
    ax.set_xlabel("Region")
    ax.set_ylabel("Revenue (₹)")
    st.pyplot(fig)


def main():
    st.title("📊 Sales & Business Analytics Dashboard")
    st.caption(
        "End-to-end analytics pipeline on a retail dataset of 100,000+ records — "
        "cleaned with Pandas/SQL, KPIs analysed, and visualised with an interactive, "
        "drill-down Streamlit dashboard."
    )

    df = load_data()

    # --- Sidebar filters (drill-down) ---
    st.sidebar.header("Filters")

    min_date, max_date = df["order_date"].min(), df["order_date"].max()
    date_range = st.sidebar.date_input(
        "Order date range", value=(min_date, max_date), min_value=min_date, max_value=max_date
    )

    regions = st.sidebar.multiselect(
        "Region", options=sorted(df["region"].unique()), default=sorted(df["region"].unique())
    )
    categories = st.sidebar.multiselect(
        "Product category",
        options=sorted(df["product_category"].unique()),
        default=sorted(df["product_category"].unique()),
    )

    if isinstance(date_range, tuple) and len(date_range) == 2:
        start_date, end_date = date_range
    else:
        start_date, end_date = min_date, max_date

    mask = (
        (df["order_date"] >= pd.to_datetime(start_date))
        & (df["order_date"] <= pd.to_datetime(end_date))
        & (df["region"].isin(regions))
        & (df["product_category"].isin(categories))
    )
    filtered = df.loc[mask]

    if filtered.empty:
        st.warning("No data matches the selected filters. Adjust the filters in the sidebar.")
        return

    kpi_cards(filtered)

    col1, col2 = st.columns(2)
    with col1:
        category_chart(filtered)
    with col2:
        region_chart(filtered)

    monthly_trend_chart(filtered)

    with st.expander("🔍 View filtered data"):
        st.dataframe(filtered.sort_values("order_date", ascending=False), use_container_width=True)


if __name__ == "__main__":
    main()
